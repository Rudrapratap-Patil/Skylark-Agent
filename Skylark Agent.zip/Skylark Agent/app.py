import streamlit as st
import requests
import pandas as pd
import plotly.express as px
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, ListFlowable, ListItem
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib import colors
from reportlab.lib.units import inch

# ---------------- CONFIG ----------------
st.set_page_config(page_title="Executive BI Agent", layout="wide")

MONDAY_API_KEY = st.secrets["MONDAY_API_KEY"]
WORK_BOARD_ID = st.secrets["WORK_BOARD_ID"]
DEAL_BOARD_ID = st.secrets["DEAL_BOARD_ID"]

st.title("Monday.com Business Intelligence Agent")
st.caption("Founder-level insights across Deals & Work Orders")

# ---------------- MONDAY API FETCH ----------------
def fetch_board(board_id):
    query = f"""
    query {{
      boards(ids: {board_id}) {{
        items_page(limit: 500) {{
          items {{
            name
            column_values {{
              id
              text
            }}
          }}
        }}
      }}
    }}
    """
    headers = {"Authorization": MONDAY_API_KEY}
    response = requests.post(
        "https://api.monday.com/v2",
        json={"query": query},
        headers=headers,
    )
    data = response.json()
    items = data["data"]["boards"][0]["items_page"]["items"]

    rows = []
    for item in items:
        row = {"name": item["name"]}
        for col in item["column_values"]:
            row[col["id"]] = col["text"]
        rows.append(row)

    return pd.DataFrame(rows)

# ---------------- LOAD DATA ----------------
@st.cache_data
def load_data():
    return fetch_board(DEAL_BOARD_ID), fetch_board(WORK_BOARD_ID)

deals_df, work_df = load_data()

# ---------------- COLUMN MAPPING ----------------
DEAL_VALUE_COL = "numeric_mm0f3qwk"
STAGE_COL = "color_mm0f9tk8"
SECTOR_COL = "color_mm0ftxe7"
CLOSE_DATE_COL = "date_mm0fefc3"

# ---------------- DATA CLEANING ----------------
deals_df.fillna("", inplace=True)
work_df.fillna("", inplace=True)

if SECTOR_COL in deals_df.columns:
    deals_df[SECTOR_COL] = deals_df[SECTOR_COL].str.lower().str.strip()

# ---------------- SIDEBAR FILTER ----------------
st.sidebar.header("Filters")

sector_list = sorted(deals_df.get(SECTOR_COL, pd.Series()).unique())
selected_sector = st.sidebar.selectbox("Select Sector", ["All"] + list(sector_list))

if selected_sector != "All":
    deals_df = deals_df[deals_df[SECTOR_COL] == selected_sector]

# ---------------- KPI CALCULATIONS ----------------
if DEAL_VALUE_COL in deals_df.columns:
    deals_df[DEAL_VALUE_COL] = pd.to_numeric(deals_df[DEAL_VALUE_COL], errors="coerce").fillna(0)
    pipeline_value = deals_df[DEAL_VALUE_COL].sum()
else:
    pipeline_value = 0

active_deals = len(deals_df)
active_work_orders = len(work_df)

# ---------------- KPI DISPLAY ----------------
col1, col2, col3 = st.columns(3)
col1.metric("Total Pipeline (₹)", f"{int(pipeline_value):,}")
col2.metric("Active Deals", active_deals)
col3.metric("Active Work Orders", active_work_orders)

st.divider()

# ---------------- PIPELINE BREAKDOWN ----------------
st.subheader("Pipeline Stage Breakdown")

if STAGE_COL in deals_df.columns:
    stage_counts = deals_df[STAGE_COL].value_counts().reset_index()
    stage_counts.columns = ["Stage", "Count"]
    fig = px.bar(stage_counts, x="Stage", y="Count")
    st.plotly_chart(fig, use_container_width=True)

st.divider()

# ---------------- QUARTER FUNCTION ----------------
def current_quarter_dates():
    today = pd.Timestamp.today()
    quarter = (today.month - 1) // 3 + 1
    start_month = 3 * (quarter - 1) + 1
    start = pd.Timestamp(today.year, start_month, 1)
    end = start + pd.offsets.QuarterEnd()
    return start, end

# ---------------- FOUNDER Q&A (INTELLIGENT VERSION) ----------------
st.subheader("Ask a Business Question")

question = st.text_input("Example: How is energy sector performing this quarter?")

if st.button("Analyze"):

    q = question.lower()
    filtered_deals = deals_df.copy()

    # -------- Detect Sector --------
    detected_sector = None
    if SECTOR_COL in filtered_deals.columns:
        for sector in filtered_deals[SECTOR_COL].unique():
            if sector and sector in q:
                detected_sector = sector
                filtered_deals = filtered_deals[
                    filtered_deals[SECTOR_COL] == sector
                ]
                break

    # -------- Quarter Logic --------
    if CLOSE_DATE_COL in filtered_deals.columns:
        filtered_deals[CLOSE_DATE_COL] = pd.to_datetime(
            filtered_deals[CLOSE_DATE_COL],
            errors="coerce"
        )

        today = pd.Timestamp.today()
        current_q = (today.month - 1) // 3 + 1
        current_start = pd.Timestamp(today.year, 3*(current_q-1)+1, 1)
        current_end = current_start + pd.offsets.QuarterEnd()

        last_end = current_start - pd.Timedelta(days=1)
        last_q = (last_end.month - 1)//3 + 1
        last_start = pd.Timestamp(last_end.year, 3*(last_q-1)+1, 1)
        last_q_end = last_start + pd.offsets.QuarterEnd()

        current_q_df = filtered_deals[
            (filtered_deals[CLOSE_DATE_COL] >= current_start) &
            (filtered_deals[CLOSE_DATE_COL] <= current_end)
        ]

        last_q_df = filtered_deals[
            (filtered_deals[CLOSE_DATE_COL] >= last_start) &
            (filtered_deals[CLOSE_DATE_COL] <= last_q_end)
        ]
    else:
        current_q_df = filtered_deals
        last_q_df = pd.DataFrame()

    # -------- Metrics --------
    current_pipeline = current_q_df[DEAL_VALUE_COL].sum()
    last_pipeline = last_q_df[DEAL_VALUE_COL].sum()

    deal_count = len(current_q_df)

    growth_percent = 0
    if last_pipeline > 0:
        growth_percent = ((current_pipeline - last_pipeline) / last_pipeline) * 100

    avg_deal = current_pipeline / deal_count if deal_count > 0 else 0

    # -------- Aging Deals --------
    aging_deals = 0
    if CLOSE_DATE_COL in current_q_df.columns:
        today = pd.Timestamp.today()
        aging_deals = len(
            current_q_df[
                (today - current_q_df[CLOSE_DATE_COL]).dt.days > 90
            ]
        )

    # -------- Narrative Generation --------
    tone = "stable"

    if growth_percent > 15:
        tone = "showing strong growth"
    elif growth_percent < -10:
        tone = "slowing down compared to last quarter"

    response = f"""
### Energy Sector Performance Overview

The energy pipeline this quarter is ₹{int(current_pipeline):,} 
across {deal_count} active deals.

Compared to last quarter, performance is **{tone}** 
with a change of {growth_percent:.1f}%.

The average deal size stands at ₹{int(avg_deal):,}.
"""

    if aging_deals > 0:
        response += f"\n\n⚠ {aging_deals} deals have been open for more than 90 days, indicating potential closing delays."

    if current_pipeline == 0:
        response += "\n\n⚠ No deal activity recorded for the selected criteria."

    st.markdown(response)
